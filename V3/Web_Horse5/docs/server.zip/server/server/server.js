const express = require("express");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const path = require("path");
const mysql = require("mysql2/promise");

const app = express();
let db; // connexion globale

// ===============================
// INIT DATABASE
// ===============================
async function initDB() {
    try {
        db = await mysql.createConnection({
            host: "mysql-tagadateam.alwaysdata.net",
            user: "448191",
            password: "T@g@d@.Polytech",
            database: "tagadateam_base",
            ssl: {}
        });
        console.log("✔ Connecté à la base de données");
    } catch (err) {
        console.error("❌ Erreur DB :", err);
        process.exit(1);
    }
}

// ===============================
// MIDDLEWARES
// ===============================
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Définir le chemin des fichiers statiques
const publicPath = path.join(__dirname, "..", "..");
app.use(express.static(publicPath));

// Session
app.use(session({
    secret: "secret-key",
    resave: false,
    saveUninitialized: false
}));

// ===============================
// ROUTES
// ===============================

// Page principale
app.get("/", (req, res) => {
    res.sendFile(path.join(publicPath, "index.html"));
});

// -------------------------------
// INSCRIPTION
// -------------------------------
app.post("/register", async (req, res) => {
    const { nom, prenom, date_naissance, sexe, image_cheval } = req.body;

    try {
        const [ecurie] = await db.execute(
            "SELECT id FROM ecurie WHERE chemin_image = ?",
            [image_cheval]
        );

        const chevalId = ecurie.length ? ecurie[0].id : null;
        const hash = bcrypt.hashSync(prenom, 10);

        await db.execute(
            "INSERT INTO users (nom, mot_de_passe, date_naissance, sexe, chevaux) VALUES (?, ?, ?, ?, ?)",
            [nom, hash, date_naissance, sexe, chevalId]
        );

        req.session.user = { nom };
        res.send("Inscription réussie");

    } catch (err) {
        if (err.code === "ER_DUP_ENTRY") {
            return res.send("Identifiant déjà utilisé");
        }
        console.error(err);
        res.status(500).send("Erreur serveur");
    }
});

// -------------------------------
// LOGIN
// -------------------------------
app.post("/login", async (req, res) => {
    const { nom, prenom } = req.body;

    const [rows] = await db.execute(
        "SELECT * FROM users WHERE nom = ?",
        [nom]
    );

    if (!rows.length) return res.send("Identifiant introuvable");

    const user = rows[0];

    if (!bcrypt.compareSync(prenom, user.mot_de_passe)) {
        return res.send("Nom de cheval incorrect");
    }

    req.session.user = user;
    res.redirect("/");
});

// -------------------------------
// SESSION
// -------------------------------
app.get("/api/user", (req, res) => {
    res.json(req.session.user ? { loggedIn: true, user: req.session.user } : { loggedIn: false });
});

// -------------------------------
// COULEURS PAR RACE
// -------------------------------
app.get("/api/couleurs", async (req, res) => {
    const raceId = req.query.race_id;
    if (!raceId) {
        return res.status(400).json({ error: "race_id manquant" });
    }

    try {
        const [rows] = await db.execute(
            "SELECT id, nom, preview_image FROM couleurs WHERE race_id = ?",
            [raceId]
        );
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Erreur serveur" });
    }
});

// -------------------------------
// CHEVAL PAR RACE + COULEUR
// -------------------------------
app.get("/api/cheval/:race", async (req, res) => {
    const { race } = req.params;
    const { couleur } = req.query;

    if (!couleur) return res.status(400).json({ error: "Couleur manquante" });

    try {
        const [rows] = await db.execute(
            `SELECT couche, layer_order, image_path
             FROM chevaux_images
             WHERE race = ? AND couleur = ?
             ORDER BY layer_order ASC`,
            [race, couleur]
        );

        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Erreur serveur" });
    }
});


// -------------------------------
// IMAGES PAR RACE (PERSONNALISATION)
// -------------------------------
// -------------------------------
// CHEVAUX POUR PERSONNALISATION
// -------------------------------
app.get("/api/chevaux_personnalisation", async (req, res) => {
    const race = req.query.race;
    if (!race) return res.status(400).json({ error: "race manquante" });

    try {
        const [rows] = await db.execute(
            `SELECT id, couche, image_path
             FROM chevaux_images
             WHERE race = ? 
             ORDER BY layer_order ASC`,
            [race]
        );

        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Erreur serveur" });
    }
});







// ===============================
// START SERVER
// ===============================
async function start() {
    await initDB();
    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => {
        console.log(`🚀 Serveur lancé sur http://localhost:${PORT}`);
    });
}

start();
