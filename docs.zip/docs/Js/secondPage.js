document.getElementById("formulaire_cheval").addEventListener("submit", function(e) {
    e.preventDefault();
    window.location.href = "/main_page";
});
